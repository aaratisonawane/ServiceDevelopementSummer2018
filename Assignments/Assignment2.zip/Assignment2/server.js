var express=require('express');
var fs=require('fs');
var qs = require('querystring');

var app=express();

app.get('/',function(req,res){
    res.sendFile(__dirname+'/index.html');
});
app.get('/todo.js',function(req,res){
    res.sendFile(__dirname+'/todo.js');
});
app.get('/todo.css',function(req,res){
    res.sendFile(__dirname+'/todo.css');
});
app.post('/todos', function(req,res){ //**** http request receiver ****
	var fs = require('fs');
	console.log(req.query);
	var data = req.query;
	fs.writeFile("/Users/rb034746/Desktop/aarati.txt", JSON.stringify(data), function(err) {
    	if(err) {
        	return console.log(err);
    	}
		console.log("The file was saved!");
	}); 
  var myTestVar = "Hello World";
  return res.send(myTestVar);
});

app.listen(3000);
console.log("App listening on port " + 3000);